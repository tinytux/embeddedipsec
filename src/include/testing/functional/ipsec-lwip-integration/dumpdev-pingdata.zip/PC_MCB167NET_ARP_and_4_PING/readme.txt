Windows 2000 Professional workstation (192.168.1.2) is sending 4 ICMP ping packets 
to MCB167-NET running lwIP (192.168.1.3). 
